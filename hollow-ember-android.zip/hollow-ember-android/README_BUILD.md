# Hollow Ember – Android build

Requirements: Node 18+, JDK 17, Android Studio (or the Android SDK command-line tools with ANDROID_HOME set). Internet is needed once, to download dependencies.

    npm install
    npm run setup      # adds the Android project, forces landscape + fullscreen, generates icon + splash
    npm run apk        # builds android/app/build/outputs/apk/debug/app-debug.apk

Install: `adb install -r android/app/build/outputs/apk/debug/app-debug.apk` (or copy the APK to the phone).
Or open the `android/` folder in Android Studio and press Run.

After editing `www/index.html`, run `npm run sync` and rebuild.

The game is a single file with no external links, so it runs offline. The Arabic font is the system Noto Naskh Arabic that ships with Android; the game falls back to other system fonts if it is missing. Progress is stored in WebView localStorage and survives closing the app.

STATUS: this project has NOT been built into an APK or run on a device. The web game itself was tested in headless Chromium (see notes in the chat).
